package com.cg.demo;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class EmployeeService extends EmployeeRepository {

	public List<Employee> getEmployees(Double salary) {
		// display all the employees where the salary is greater than 60000
		return employees.stream().filter(k -> k.getSalary() > salary).collect(Collectors.toList());
	}

	public Double getMaxSalary() {
		// display the maximum salary from the list of employees
		Optional<Double> result = employees.stream().map(Employee::getSalary).collect(Collectors.reducing(Double::max));
		if (result.isPresent())
			return result.get();
		return 0.0;

	}

	public Double getSumOfSalary() {
		// display the sum of salaries of all the employees
		return employees.stream().collect(Collectors.summingDouble(Employee::getSalary));

	}

	public List<String> getNames(String city) {
		// display the names of all employees who are working in 'Pune'
		return employees.stream().filter(k -> k.getLocation().equals(city)).map(k -> k.getName())
				.collect(Collectors.toList());

	}

	public List<Employee> getDetails() {
		// display all employees based on salary ascending
		return employees.stream().sorted(Comparator.comparingDouble(Employee::getSalary)).collect(Collectors.toList());

	}

	public List<Employee> getManagers() {
		// display all employees who are working as managers
		return employees.stream().filter(k -> k.getDesignation().equals("Manager")).collect(Collectors.toList());

	}

	public Double getSumOfManagerSalaries() {
		// display the sum of salaries of employees who are working as managers
		// Double SumOfManagerSalary = ((Collection<Employee>)
		// employees).stream().filter(d->d.getDesignation().startsWith("Manager")).mapToDouble(s->s.getSalary()).sum();
		List<Employee> l4 = employees.stream().filter(k -> k.getDesignation().equals("Manager"))
				.collect(Collectors.toList());

		return l4.stream().collect(Collectors.summingDouble(Employee::getSalary));

	}
}