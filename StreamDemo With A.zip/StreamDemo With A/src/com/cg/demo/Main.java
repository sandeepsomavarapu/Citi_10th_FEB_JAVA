package com.cg.demo;

public class Main {
	public static void main(String[] args) {
		EmployeeService service = new EmployeeService();
		System.out.println("display all employees based on salary ascending");
		service.getDetails().stream().forEach(System.out::println);

		System.out.println("*************************************");

		System.out.println("Employees where the salary is greater than 60000");

		service.getEmployees(60000.0).stream().forEach(System.out::println);

		System.out.println("the max salary from above details :" + service.getMaxSalary());

		System.out.println("sum of salaries of all the employees :" + service.getSumOfSalary());

		System.out.println("all employees who are working in 'Pune'");

		service.getNames("Pune").stream().forEach(System.out::println);

		System.out.println("display all employees who are working as managers");
		service.getManagers().stream().forEach(System.out::println);
		System.out.println(
				"sum of salaries of employees who are working as managers" + service.getSumOfManagerSalaries());

	}

}
